import pandas as pd
import numpy as np
import os
from datetime import datetime,date, timedelta
import holidays
# !pip install matplotlib
# !pip install seaborn
import matplotlib.pyplot as plt
import seaborn as sns

current_directory = os.path.dirname(os.path.abspath(__file__))

pd.set_option('display.max_columns', None)
pd.set_option('display.max_rows', None)
# pd.set_option('display.max_colwidth', None)
# pd.set_option('display.float_format', lambda x: f'{x:.2f}')


#AUX FUNCTIONS

def easter_date(year): #DATA PASCOA
   "Returns Easter as a date object."
   a = year % 19
   b = year // 100
   c = year % 100
   d = b // 4
   e = b % 4
   f = (b + 8) // 25
   g = (b - f + 1) // 3
   h = (19 * a + b - d - g + 15) % 30
   i = c // 4
   k = c % 4
   l = (32 + 2 * e + 2 * i - h - k) % 7
   m = (a + 11 * h + 22 * l) // 451
   month = (h + l - 7 * m + 114) // 31
   day = ((h + l - 7 * m + 114) % 31) + 1
   return datetime(year, month, day).date()

def get_carnival_date(year): #DATA CARNAVAL (CARNAVAL N É FERIADO OFICIAL NA BIBLIOTECA HOLIDAYS pois não é um feriado nacional oficial no Brasil)
    easter = easter_date(year)
    carnival = easter - timedelta(days=47)
    return carnival

def get_feriados(d_init, d_final, ph):
    
    start_date = datetime.strptime(d_init, '%Y-%m-%d')
    end_date = datetime.strptime(d_final, '%Y-%m-%d')
    years = list(range(start_date.year, end_date.year + 1))

    brazil_holidays = holidays.Brazil(years=years)

    for year in brazil_holidays.years:
        carnival_date = get_carnival_date(year)
        brazil_holidays[carnival_date] = "Carnaval"

    dfh = pd.DataFrame(columns=["data", "feriado"])

    for date, name in sorted(brazil_holidays.items()):
        dfh = pd.concat([dfh, pd.DataFrame({"data": [date], "feriado": [name]})], ignore_index=True)
    dfh.to_csv(ph, index=False)
    return dfh
# Função para converter a string de tempo para minutos

def string_to_time(duration_str, unit='minutes'):
    parts = duration_str.split()
    days = int(parts[0].replace("d", "")) if parts[0].startswith("0d") else 0
    time_str = parts[1]
    hours, minutes, seconds = map(int, time_str.split(":"))

    total_seconds = days * 24 * 3600 + hours * 3600 + minutes * 60 + seconds

    if unit == 'minutes':
        return total_seconds // 60
    elif unit == 'hours':
        return total_seconds // 3600
    elif unit == 'days':
        return total_seconds // (24 * 3600)
    else:
        raise ValueError("Unit must be one of 'minutes', 'hours', or 'days'")
#Logica para Definir Curto Prazo
def is_cp(num_du):
    if pd.isnull(num_du):
        return np.nan
    else:
        return (num_du >= 1) and (num_du <= 9)

#Main Function

exec_ini = datetime.today()
print(f"Start Running...{exec_ini}")
    
pi = pathInput = os.path.join(current_directory,f'INPUT')
po = pathOutput = os.path.join(current_directory,f'OUTPUT')
for root, dirs, files in os.walk(pathInput):
    print(f'Diretório: {root}')
    for file_name in files:
        if ".csv" in file_name:
            print(f' - Arquivo de Base do Blip: {file_name} Encontrado')
            bf = baseFile = file_name
        if ".xlsx" in file_name:
            print(f' - Arquivo de Ferias: {file_name} Encontrado')
            ff = feriasFile = file_name
hf = holidaysFile = 'holidays.csv'
ph = pathHolidays = os.path.join(current_directory,f'{hf}')
pf = pathFerias = os.path.join(pi,f'{ff}')
pibf = pathInputBaseFile = os.path.join(pi,f'{bf}')
df_base = pd.read_csv(pibf,index_col=None,sep='\t')
d_ini = pd.to_datetime(df_base['CloseDate'],format='%Y-%m-%d %H:%M:%S',errors='coerce').min().replace(day=1).strftime('%Y-%m-%d')
d_fin = pd.to_datetime(df_base['CloseDate'],format='%Y-%m-%d %H:%M:%S',errors='coerce').max().strftime('%Y-%m-%d')
df_feriados = get_feriados(d_ini, d_fin, ph)
df_feriados["data"] = pd.to_datetime(df_feriados['data'], format='%Y-%m-%d')
ferias = pd.read_excel(pf)
ferias["INICIO"] = pd.to_datetime(ferias['INICIO'], format='%d/%m/%Y')
ferias["FIM"] = pd.to_datetime(ferias['FIM'], format='%d/%m/%Y')
usuarios = df_base['AgentIdentity'].drop_duplicates()
datas_entre = pd.date_range(start=d_ini, end=d_fin).to_list()
df_0 = pd.DataFrame(datas_entre,columns=["data"])

#Logica para calcular dias uteis
print("Calculando Dias Úteis...")
df_0["mes"] = df_0["data"].dt.month
df_0["dia_mes"] = df_0["data"].dt.day
df_0['IsWeekday'] = df_0['data'].dt.weekday < 5
df_weekdays = df_0[df_0['IsWeekday']]
df_1 = df_0
df_1 = pd.merge(df_0,df_feriados,on='data',how="left")
df_1['isFeriado'] = df_1['feriado'].apply(lambda x: isinstance(x, str) and x.strip() != '')
df_1['isDiaUtil'] = df_1['IsWeekday'] & ~df_1['isFeriado']
df_1['num_du'] = df_1.groupby(df_1['data'].dt.to_period('M'))['isDiaUtil'].cumsum().where(df_1['isDiaUtil'])
df_1.fillna(np.nan, inplace=True)


print("Definindo Curto Prazo...")
df_1['isCP'] = df_1['num_du'].apply(lambda x: is_cp(x))



#Inserindo colunas de Ferias
print(f"Verificando Ferias... ")
for u in usuarios:
    df_1[u] = pd.NA
    for i, row in df_1.iterrows():
        df_1.at[i,u] = any(
            (u == ferias['AgentIdentity']) &
            (df_1.loc[i,'data'] >= ferias['INICIO']) &
            (df_1.loc[i,'data'] <= ferias['FIM'])
        )
        if any(
            (u == ferias['AgentIdentity']) &
            (row['data'] >= ferias['INICIO']) &
            (row['data'] <= ferias['FIM'])
            ): 
            print(f"{u} : {df_1.at[i,'data']}")

#Criando Usuarios em DataFrames Separadamente
df_base['CloseDate'] = pd.to_datetime(df_base['CloseDate'].str.slice(0, 10))
df_base['CloseDate'] = df_base['CloseDate'].dt.strftime('%Y-%m-%d')

df_users= []
print("\nCriando DataFrames Separadamente...\n")
for u in usuarios:
    df_user = pd.DataFrame(df_1[["data","isCP",u]])

    # df_user['data'] = pd.to_datetime(df_user['data'].str.slice(0, 10))
    df_user["data"] = df_user['data'].dt.strftime('%Y-%m-%d')
    # display(df_user)
    df_user = df_user.rename(columns={u:'Ferias'})
    df_user.loc[:, 'AgentIdentity'] = f"{u}"
    df_user = pd.merge( df_user, df_base,  left_on=['data', 'AgentIdentity'],right_on=['CloseDate', 'AgentIdentity'], how='inner',suffixes=('_user', '_base'))    
    if not df_user.empty:
        df_user.to_csv(os.path.join(pathOutput,f"base_{u}.csv"))
        print("Salvo em: ",os.path.join(pathOutput,f"base_{u}.csv"))
        df_users.append(df_user)


# Tratando os dados por agente para Fazer média ==

''' OBSERVACAO 
Considerar na media apenas os status:
    ClosedAttendant
    ClosedClientInactivity
    ClosedClient
'''

print("\nTratando dados...\n")

status_considerados = ['ClosedAttendant', 'ClosedClientInactivity', 'ClosedClient']
for n,df_user in enumerate(df_users):
    colunas = ["data","AgentIdentity","isCP","Ferias","Status","Closed","FirstResponseTime","OperationalTime","TicketTotalTime","AverageAgentResponseTime","Tags"]
    df_user = df_user[colunas]
    print("AgentIdentity","-",df_user.loc[0, 'AgentIdentity'], "(Done)")
    if  not df_user.empty:
        # Filtro por Status
        df_user = df_user[df_user['Status'].isin(status_considerados)].dropna().reset_index(drop=True)  # <Filtro por Status
        # print("Filtro por Status:",status_considerados)
        
        df_user['data'] = df_user['data'].apply(pd.to_datetime)
        df_user['FirstResponseTime(in_minutes)'] = df_user['FirstResponseTime'].apply(lambda x: string_to_time(x, unit='minutes'))
        df_user['FirstResponseTime(in_hours)'] = df_user['FirstResponseTime'].apply(lambda x: string_to_time(x, unit='hours'))
        df_user['FirstResponseTime(in_days)'] = df_user['FirstResponseTime'].apply(lambda x: string_to_time(x, unit='days'))

        df_user['OperationalTime(in_minutes)'] = df_user['OperationalTime'].apply(lambda x: string_to_time(x, unit='minutes'))
        df_user['OperationalTime(in_hours)'] = df_user['OperationalTime'].apply(lambda x: string_to_time(x, unit='hours'))
        df_user['OperationalTime(in_days)'] = df_user['OperationalTime'].apply(lambda x: string_to_time(x, unit='days'))

        df_user['TicketTotalTime(in_minutes)'] = df_user['TicketTotalTime'].apply(lambda x: string_to_time(x, unit='minutes'))
        df_user['TicketTotalTime(in_hours)'] = df_user['TicketTotalTime'].apply(lambda x: string_to_time(x, unit='hours'))
        df_user['TicketTotalTime(in_days)'] = df_user['TicketTotalTime'].apply(lambda x: string_to_time(x, unit='hours'))

        df_user['AverageAgentResponseTime(in_minutes)'] = df_user['AverageAgentResponseTime'].apply(lambda x: string_to_time(x, unit='minutes'))
        df_user['AverageAgentResponseTime(in_hours)'] = df_user['AverageAgentResponseTime'].apply(lambda x: string_to_time(x, unit='hours'))
        df_user['AverageAgentResponseTime(in_days)'] = df_user['AverageAgentResponseTime'].apply(lambda x: string_to_time(x, unit='hours'))

        # AverageAgentResponseTime
        
        df_users[n] = df_user
        df_user.to_csv(os.path.join(pathOutput,f"tratado_{df_user.loc[0, 'AgentIdentity']}.csv"))


print("\nCalculando Média...\n")

df_users_m = []

for df_user in df_users:
    # display(df_user)
    
    df_user = df_user.dropna(subset=['isCP']).reset_index(drop=True)
    # Criar uma coluna de ano-mês
    df_user['data'] = pd.to_datetime(df_user['data'])
    df_user['ano_mes'] = df_user['data'].dt.to_period('M')

    # Agrupar por ano-mês

    df_user['ano_mes'] = df_user['data'].dt.to_period('M')

    # Selecionar colunas específicas e agrupar por ano-mês
    
    df_user_m= df_user.groupby(['ano_mes',"AgentIdentity","isCP"]).agg({
        "Closed": 'sum',
        "TicketTotalTime(in_minutes)": 'mean',
    }).reset_index()

    # df_user_m.rename(columns={"ano_mes":"periodo"},inplace=True)
    # df_user_m.rename(columns={"TicketTotalTime(in_minutes)":"tempo_medio(minutos)"},inplace=True)
    # df_user_m.rename(columns={"Closed":"atendimento_concluido"},inplace=True)
    
    
    df_user_m.to_excel(os.path.join(pathOutput,f"media_mes_{df_user.loc[0, 'AgentIdentity']}.xlsx"))
    df_users_m.append(df_user_m)
    print("Salvo em: ",os.path.join(pathOutput,f"media_mes_{df_user.loc[0, 'AgentIdentity']}.xlsx"))
    # display(df_user_m)
print("\ncalculando Total...\n")
df_concat_users_m = pd.DataFrame(columns = df_user_m.columns)
for df_user_m in df_users_m:
    df_concat_users_m = pd.concat([df_concat_users_m, df_user_m])
df_concat_users_m.to_excel(os.path.join(pathOutput,f"media_mes_USUARIOS_CONCATENADOS.xlsx"))
print("Salvo em: ",os.path.join(pathOutput,f"media_mes_USUARIOS_CONCATENADOS.xlsx"))

df_total_m= df_concat_users_m.groupby(['ano_mes',"isCP"]).agg({
        "Closed": 'sum',
        "TicketTotalTime(in_minutes)": 'mean',
    }).reset_index()

# display(df_total_m)
df_total_m.to_excel(os.path.join(pathOutput,f"media_mes_TOTAL.xlsx"))
print("Salvo em: ",os.path.join(pathOutput,f"media_mes_TOTAL.xlsx"))



# Calcular média por ano e mês

# display(media_por_mes)

exec_end = datetime.today()
print(f"\nEnd Running...{exec_end}\n")
exec_time = exec_end-  exec_ini
print(f"\nExecution Time: {exec_time}\n")
